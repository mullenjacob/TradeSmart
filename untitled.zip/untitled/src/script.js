document.addEventListener("DOMContentLoaded", function() {
  const viewChartBtn = document.getElementById("view-chart-btn");
  const stockInput = document.getElementById("stock-input");
  const widgetContainer = document.getElementById("tradingview-widget");
  const loadingSpinner = document.getElementById("loading-spinner");

  viewChartBtn.addEventListener("click", function() {
    const stockSymbol = stockInput.value.trim().toUpperCase();
    if (stockSymbol) {
      loadingSpinner.classList.remove("hidden");
      loadTradingViewWidget(stockSymbol);
    } else {
      alert("Please enter a stock symbol.");
    }
  });

  function loadTradingViewWidget(stockSymbol) {
    widgetContainer.innerHTML = "";  // Clear previous widget
    new TradingView.widget({
      symbol: stockSymbol,
      container_id: "tradingview-widget",
      width: "100%",
      height: "500",
      theme: "light",
      style: "1",
      locale: "en",
      toolbar_bg: "#f1f3f6",
      enable_publishing: false,
      allow_symbol_change: true,
      details: true,
      hotlist: true,
      calendar: true,
    });
    loadingSpinner.classList.add("hidden");
  }

  // Dark Mode Toggle
  const darkModeToggle = document.getElementById("dark-mode-toggle");
  darkModeToggle.addEventListener("click", function() {
    document.body.classList.toggle("dark-mode");
  });

  // Portfolio Management
  const addToPortfolioBtn = document.getElementById("add-to-portfolio-btn");
  const portfolioStockInput = document.getElementById("portfolio-stock");
  const buyPriceInput = document.getElementById("buy-price");
  const currentPriceInput = document.getElementById("current-price");
  const sharesInput = document.getElementById("shares");
  const portfolioList = document.getElementById("portfolio-list");
  const totalGainElement = document.getElementById("total-gain");

  let totalGain = 0;

  addToPortfolioBtn.addEventListener("click", function() {
    const stockSymbol = portfolioStockInput.value.trim().toUpperCase();
    const buyPrice = parseFloat(buyPriceInput.value.trim());
    const currentPrice = parseFloat(currentPriceInput.value.trim());
    const shares = parseInt(sharesInput.value.trim());

    if (stockSymbol && !isNaN(buyPrice) && !isNaN(currentPrice) && !isNaN(shares)) {
      addStockToPortfolio(stockSymbol, buyPrice, currentPrice, shares);
      updateTotalGain();
    } else {
      alert("Please enter valid values for all fields.");
    }
  });

  function addStockToPortfolio(stockSymbol, buyPrice, currentPrice, shares) {
    const listItem = document.createElement("li");
    const gain = ((currentPrice - buyPrice) * shares).toFixed(2);
    listItem.textContent = `${stockSymbol}: Buy Price $${buyPrice.toFixed(2)}, Current Price $${currentPrice.toFixed(2)}, Shares ${shares}, Gain $${gain}`;
    portfolioList.appendChild(listItem);
  }

  function updateTotalGain() {
    totalGain = 0;
    const portfolioItems = portfolioList.querySelectorAll("li");
    portfolioItems.forEach(item => {
      const gainText = item.textContent.match(/Gain \$([0-9.]+)/);
      if (gainText) {
        totalGain += parseFloat(gainText[1]);
      }
    });
    totalGainElement.textContent = `Total Gain: $${totalGain.toFixed(2)}`;
  }

  // Historical Data Handling (Placeholder, needs API or data source integration)
  const viewHistoricalBtn = document.getElementById("view-historical-btn");
  const downloadDataBtn = document.getElementById("download-data-btn");
  const historicalChart = document.getElementById("historical-chart");
  const timeframeSelect = document.getElementById("timeframe-select");

  viewHistoricalBtn.addEventListener("click", function() {
    const timeframe = timeframeSelect.value;
    // Placeholder for fetching and displaying historical data
    historicalChart.innerHTML = `<p>Displaying historical data for ${timeframe}...</p>`;
  });

  downloadDataBtn.addEventListener("click", function() {
    // Placeholder for downloading data
    alert("Data download functionality is not yet implemented.");
  });
});
